package oot.game;

/**
 * Enumeration with the GameKI diffitultys.
 * @author Christian Coenen
 *
 */
public enum Difficulty
{
	EASY, MEDIUM, HARD;
}
