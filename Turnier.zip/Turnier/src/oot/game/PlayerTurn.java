package oot.game;

public enum PlayerTurn
{
	TURNPLAYER_1, TURNPLAYER_2;
}
