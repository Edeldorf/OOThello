package oot.game;

public enum GamePhase
{
	SET, REGULAR;
}
