package turnier;

public interface Turnier {

	public void initializeBoard(int size);
	public void printBoard();
	public void startGame(boolean isWhitePlayer);
	public int whoHasWon();
	public boolean CanIMove();
	public boolean CanYouMove();
	public String getBestTurn();
	public String[] setStone(String coordinate);
	public void setStoneInStartPhase(String coordinate);
	public boolean isMoveValid(String coordinate, boolean isWhite);
	public boolean isMoveValidInStartPhase(String coordinate);
}
