package turnier;

/**
 * Enumeration f�r die verschiedenen Richtungen in welcher Nachbarsteine
 * berechnet werden
 */

public enum Direction {
	Left(-1, 0), TopLeft(-1, -1), Top(0, -1), TopRight(1, -1), Right(1, 0), BottomRight(1, 1), Bottom(0,
			1), BottomLeft(-1, 1);

	private int x, y;

	Direction(int x, int y) {
		this.x = x;
		this.y = y;
	}

	int getX() {
		return x;
	}

	int getY() {
		return y;
	}
}
