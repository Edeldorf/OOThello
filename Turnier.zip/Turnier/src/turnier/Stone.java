package turnier;

/**Klasse f�r die Spielsteine
 *
 * nicht gesetzte Spielsteine haben '_' als Symbol
 *
 */

public class Stone {
	private char symbol;
	private int x, y;
	private boolean isOuterCircle;

	Stone(char symbol, int x, int y, boolean isOuterCircle ) {
		this.symbol = symbol;
		this.x = x;
		this.y = y;
		this.isOuterCircle = isOuterCircle;
	}

	/**
	 * "Dreht" einen Stein um
	 */

	public void turn() {
		if (symbol == 'X') {
			symbol = 'O';
		} else {
			symbol = 'X';
		}
	}

	public boolean isOuterCircle(){
		return isOuterCircle;
	}

	public void SetSymbol(char symbol) {
		this.symbol = symbol;
	}

	public char getSymbol() {
		return symbol;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}
}
