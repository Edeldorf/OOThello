package turnier;

import java.util.concurrent.ExecutionException;

import oot.game.TournamentClient;

public class Main {

	static Turnier player1 = new TurnierKlasse();
	static Turnier player2 = new TournamentClient();
	static int yourScore, myScore = 0;

	public static void main(String[] args) {

		play();

	}

	public static void play() {
		for (int i = 0; i < 100; i++) {
			player1.initializeBoard(12);
			player2.initializeBoard(12);
			player1.startGame(i < 50);
			player2.startGame(i > 49);
			setzPhase();

			spielPhase();

			wins();
		}
		System.out.println(myScore + ":" + yourScore);
	}

	public static void setzPhase() {
		for (int i = 0; i < 6; i++) {
			String myZug = player1.getBestTurn();
			if (player1.isMoveValidInStartPhase(myZug) && player2.isMoveValidInStartPhase(myZug)) {
				player1.setStoneInStartPhase(myZug);
				player2.setStoneInStartPhase(myZug);
				player1.printBoard();
			} else {
				// throw new ExecutionException(null, null);
			}
			String yourZug = player2.getBestTurn();
				if (player1.isMoveValidInStartPhase(yourZug) && player2.isMoveValidInStartPhase(yourZug)) {
					player1.setStoneInStartPhase(yourZug);
					player2.setStoneInStartPhase(yourZug);
					player1.printBoard();
				} else {
					// throw new ExecutionException(null, null);
				}
		}
	}

	public static void spielPhase() {
		while ((player1.CanIMove() || player1.CanYouMove()) && (player2.CanIMove() || player2.CanYouMove())) {
			if (player1.CanIMove() && player2.CanYouMove()) {
				player1.setStone(player1.getBestTurn());
				player2.setStone(player1.getBestTurn());
				player1.printBoard();
			} else {
				// throw new ExecutionException(null, null);
			}
			if (player1.CanYouMove() && player2.CanIMove()) {
				player1.setStone(player2.getBestTurn());
				player2.setStone(player2.getBestTurn());
				player1.printBoard();
			} else {
				// throw new ExecutionException(null, null);
			}
		}
	}

	public static void wins() {
		if (player1.whoHasWon() == player2.whoHasWon() * -1) {
			if (player1.whoHasWon() == 1)
				myScore += 3;
			else if (player1.whoHasWon() == 0) {
				myScore += 1;
				yourScore += 1;
			} else {
				yourScore += 3;
			}
		}
	}

}