package turnier;
/**
 * Klasse f�r die KI
 *
 */
public class Player {

	private String name;
	private char symbol;

	public Player(String name, char symbol) {
		this.name = name;
		this.symbol = symbol;
	}

	public String getName() {
		return name;
	}

	/**
	 * Liefert das gegnerische Symbol
	 *
	 * @return das gegnerische Symbol
	 */

	public char getEnemySymbol() {
		if (symbol == 'X') {
			return 'O';
		}
		return 'X';
	}

	public char getSymbol() {
		return symbol;
	}

	public int getDifficulty() {
		return 0;
	}

	public void setName(String name) {
		this.name = name;
	}

}