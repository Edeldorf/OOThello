package turnier;

import turnier.GameBoard.AI;

public class TurnierKlasse implements Turnier {

	public GameBoard board = null;
	private GameBoard.AI me;
	private Player you;

	@Override
	public void initializeBoard(int size) {
		board = new GameBoard(size);
	}

	@Override
	public void printBoard() {
		board.draw();
	}

	public int count(){
		return board.countStones();
	}

	@Override
	public void startGame(boolean isWhitePlayer) {
		board.setStart();
		if (isWhitePlayer) {
			board.setPlayer("", 'O', 3);
			board.setPlayer("You", 'X', 0);
			me = (AI) board.player1;
			you = board.player2;
		} else {
			board.setPlayer("You", 'O', 0);
			board.setPlayer("", 'X', 3);
			me = (AI) board.player2;
			you = board.player1;
		}
	}

	@Override
	public int whoHasWon() {
		if (board.isWinner(me))
			return 1;
		else if (board.isWinner(you))
			return -1;
		else
			return 0;
	}

	@Override
	public boolean CanIMove() {
		return board.hasOptions();
	}

	@Override
	public boolean CanYouMove() {
		board.turn++;
		boolean r = board.hasOptions();
		board.turn--;
		return r;
	}

	@Override
	public String getBestTurn() {
		if(board.turn<12)
			return me.startPhase();
		return me.hard();
	}

	@Override
	public String[] setStone(String coordinate) {
		int x = 0;
		int y = 0;
		if (coordinate.length() == 2) {
			x = coordinate.charAt(0) - 64;
			y = coordinate.charAt(1) - 48;
		} else {
			x = coordinate.charAt(0) - 64;
			y = (coordinate.charAt(1) - 48) * 10 + (coordinate.charAt(2) - 48);
		}
		board.setStone(x-1, y-1);
		return null;
	}

	@Override
	public void setStoneInStartPhase(String coordinate) {
		setStone(coordinate);
	}

	@Override
	public boolean isMoveValid(String coordinate, boolean isWhite) {
		return isMoveValidInStartPhase(coordinate);
	}

	@Override
	public boolean isMoveValidInStartPhase(String coordinate) {
		int x = 0;
		int y = 0;
		if (coordinate.length() == 2) {
			x = coordinate.charAt(0) - 64;
			y = coordinate.charAt(1) - 48;
		} else {
			x = coordinate.charAt(0) - 64;
			y = (coordinate.charAt(1) - 48) * 10 + (coordinate.charAt(2) - 48);
		}
		return board.isPossible(x, y-1);
	}
}
